'use strict'

var Categoria = require("../modelos/categoria.model");
var Producto = require("../modelos/producto.model");
var bcrypt = require('bcrypt-nodejs');
var jwt = require("../servicios/jwt");
const categoriaModel = require("../modelos/categoria.model");

function pruebaControlador(req,res){
    res.status(200).send({message: "ControladorUsuario activo"});
}

function createProd(req, res) {

    var productoModel = new Producto(); 
var params = req.body;

if (req.user.rol == "ROL_ADMIN") {
    if (params.nombre) {
        productoModel.nombre = params.nombre;
        productoModel.cantidad = params.cantidad;
        productoModel.importe = params.importe;
        productoModel.IDCategoria = params.IDCategoria;
        Producto.find({nombre: productoModel.nombre }).exec((err, productoEncontrado) =>{
            if(err) return res.status(500).send({mensaje: "Error en peticion"});
                if(productoEncontrado && productoEncontrado.length >= 1) {
                    return res.status(500).send({ mensaje: "Producto existente"});
            }else {
                productoModel.save((err, productoGuardado) => {
                if (err) return res.status(500).send({ mensaje: "Error el guardar"});
                    if (productoGuardado) {
                    res.status(200).send({productoGuardado})
            }else{
                res.status(404).send({ mensaje: "Error al crear"})
                }
            })}
         })}
    }else{
        return res.status(500).send({ mensaje: 'Un cliente no puede agregar un producto' });
    }
}


function updateProd(req, res) {

    var IDProducto = req.params.id;
    var params = req.body; 
    Producto.find({nombre: params.nombre}).exec((err, ProductoEncontrado) =>{

    if (err) return res.status(500).send({mensaje: "Error en peticion"});
        if (ProductoEncontrado && ProductoEncontrado.length >= 1) {
        return res.status(500).send({mensaje: "Producto existente"});
}
    if (req.user.rol == "ROL_ADMIN") {
    Producto.findByIdAndUpdate(IDProducto, params, {new: true }, (err, productoActualizado) =>{
        if (err) return res.status(500).send({ mensaje: "Error en peticion" });
            if (!productoActualizado) return res.status(500).send({mensaje: "Error al editar"});
            return res.status(200).send({productoActualizado})
    })
}})
}

function deleteProd(req, res) {

    var IDCategoria= req.params.id;
    if(req.user.rol != "ROL_ADMIN"){
        return res.status(500).send({mensaje: "No puedes elimnar"});
    }
    Producto.findByIdAndDelete(IDCategoria,(err, ProductoEliminado)=>{
    if(err) return res.status(500).send({mensaje:"Error en peticion"});
    if(!ProductoEliminado) return res.status(500).send({mensaje:"Error al eliminar"});
        return res.status(500).send({mensaje: "Error al eliminar"});
    })    
}

function getProd(req, res) {

    Producto.find().exec((err, productos) => {
    if (err) return res.status(500).send({ mensaje: 'Error en la peticion de obtener Usuarios' });
    if (!productos) return res.status(500).send({ mensaje: 'Error en la consutla de Usuarios o no tiene datos' });
    return res.status(200).send({ productos });
    })


}

function getProductoCategoria(req, res) {
    
    var IDCategoria = req.params.id;
    Producto.find({IDCategoria: IDCategoria}).exec((err, productos) =>{
        if(err){res.status(500).send("Error en peticion");
        }else{
          if (!productos) return res.status(500).send({mensaje: "Categoria sin productos"})
          return res.status(500).send({productos});
        }
    })

}

function getNombre(req, res) {

    var params = req.body;
    Producto.find({nombre: params.nombre}).exec((err, productos) => {
        if(err){res.status(500).send("Error en peticion");
        }else{
          if (!productos) return res.status(500).send({mensaje: "Error al buscar"})
          return res.status(500).send({ productos });
        }})
}

function getAgotados(req, res) {

    Producto.find({cantidad: 0}).exec((err, productos) => {
        if(err){res.status(500).send("Error en peticion");
        }else{
          if (!productos) return res.status(500).send({mensaje: "Error al buscar"})
          return res.status(500).send({productos});
        }})
}

module.exports = {
    pruebaControlador,
    createProd,
    updateProd,
    getProd,
    deleteProd,
    getProductoCategoria,
    getAgotados,
    getNombre
}