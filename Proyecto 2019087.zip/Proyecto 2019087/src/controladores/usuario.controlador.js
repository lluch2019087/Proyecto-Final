"use strict"

var Categoria = require("../modelos/categoria.model");
var Usuario = require("../modelos/usuario.model");
var bcrypt = require('bcrypt-nodejs');
var jwt = require("../servicios/jwt");

function pruebaControlador(req,res){
    res.status(200).send({message: "ControladorUsuario activo"});
}

function admin(req, res) {

    var userModel = Usuario();   
    userModel.nombre= "ADMIN"
    userModel.username = "ADMIN"
    userModel.rol="ROL_ADMIN"

    Usuario.find({nombre: "ADMIN"}).exec((err, adminEncontrado)=>{
        if(err) return console.log({mensaje: "Error en creacion"});
        if(adminEncontrado && adminEncontrado.length >= 1){
        return console.log("Admin creado");

        }else{bcrypt.hash("123456", null, null, (err, passwordEncriptada)=>{
            userModel.password = passwordEncriptada;
            userModel.save((err, adminguardado)=>{
                if(err) return console.log({mensaje : "Error en la peticion"});
                if(adminguardado){console.log("Administrador preparado");
                if(adminguardado){

                }
            }})     
        })
    }})
}

function createCliente(req, res) {
    var userModel = new Usuario();
    var params = req.body;
    if (params.nombre && params.password) {
        userModel.nombre = params.nombre;
        userModel.username = params.username;
        userModel.rol = "ROL_CLIENTE";
        Usuario.find({username: userModel.username}).exec((err, clienteEncontrado)=> {
            if (err) return res.status(500).send({ mensaje: "Error en peticion" });
            if (clienteEncontrado && clienteEncontrado.length >= 1) {
            return res.status(500).send({mensaje: "cliente existente"});

            }else{
                bcrypt.hash(params.password, null, null, (err, passwordEncriptada)=> {
                userModel.password = passwordEncriptada;
                userModel.save((err, clienteGuardado) => {
                if (err) return res.status(500).send({mensaje: "Error en peticion"});

                if (clienteGuardado) {
                res.status(200).send({clienteGuardado})
            }else{
                res.status(404).send({mensaje: "Error guardar cliente"})
                        }})
                })}
        })}
}

function login(req,res){
    var params = req.body;
    Usuario.findOne({Usuario: params.Usuario}, (err, usuarioEncontrado)=> {
         if(err) return res.status(500).send({mensaje: "Error en peticion"});
              if(usuarioEncontrado){     
              bcrypt.compare(params.password, usuarioEncontrado.password, (err, passVerificada)=>{
                   if(passVerificada){
                   if(params.getToken === "true"){
                      return res.status(200).send({
                      token: jwt.createToken(usuarioEncontrado)      
    })  }else{
              usuarioEncontrado.password = undefined;
              return res.status(200).send({usuarioEncontrado})}

         }else{
              return res.status(500).send({mensaje:"Error de id"})
         }})

         }else{
              return res.status(500).send({mensaje:"Error al buscar usuario"})
         }})
}

function update(req, res) {
    var idUsuario = req.user.sub;
    var params = req.body;
    delete params.password;

    Usuario.find({username: params.username}).exec((err, Encontrada) =>{
        if (err) return res.status(500).send({mensaje: "Error en peticion"});
        if (Encontrada && Encontrada.length >= 1) {
            return res.status(500).send({mensaje: "User existente"});
    }

    if (req.user.rol != "ROL_ADMIN") {
        Usuario.findByIdAndUpdate(idUsuario, params, {new: true}, (err, usuarioActualizado) => {
        if (err) return res.status(500).send({ mensaje: "Error en peticion" });
        if (!usuarioActualizado) return res.status(500).send({mensaje: "Error en peticion"});
        return res.status(200).send({ usuarioActualizado })
        })
    }else{
        return res.status(500).send({ mensaje: "No puedes editar este user" });
    }
    
})
  
}

function deleteUser(req, res){

    var IDUsuario= req.user.sub;

    if(req.user.rol === "ROL_ADMIN"){
        return res.status(500).send({mensaje: "Error al eliminar"});
    }
    Usuario.findByIdAndDelete(IDUsuario,(err, usuarioEliminado)=>{
    if(err) return res.status(500).send({mensaje:"Error en peticion"});
    if(!usuarioEliminado) return res.status(500).send({mensaje:"Error al eliminar"});
    return res.status(200).send({mensaje: "Usuario eliminado"});
    })

    
}

module.exports = {
    pruebaControlador,
    admin,
    createCliente,
    login,
    update,
    deleteUser
}