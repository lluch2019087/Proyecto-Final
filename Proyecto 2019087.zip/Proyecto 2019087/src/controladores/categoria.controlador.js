"use strict"

var Categoria = require("../modelos/categoria.model");
var Producto = require("../modelos/producto.model");
var bcrypt = require('bcrypt-nodejs');
var jwt = require("../servicios/jwt");

function pruebaControlador(req,res){
    res.status(200).send({message: "ControladorUsuario activo"});
}

function prede(req, res) {

    var categoriaModel = Categoria();   
    categoriaModel.nombreCategoria= "Default"
    Categoria.find({nombreCategoria: "Default"}).exec((err, CategoriaEncontrada)=>{
        if(err) return console.log({mensaje: "Error en peticion"});
        if(CategoriaEncontrada.length >= 1){
        }else{
            categoriaModel.save((err, CategoriaGuardada)=>{
                if(err) return console.log({mensaje : "Error en peticion"});
                    if(CategoriaGuardada){console.log("Categoria lista");
                }else{
                console.log({mensaje:"Categoria no lista"});
                }})     
        }})
}

function createCategoria(req, res) {
    var categoriaModel = new Categoria(); 
    var params = req.body;
    if (req.user.rol === "ROL_ADMIN") {
        if (params.nombreCategoria) {
            categoriaModel.nombreCategoria = params.nombreCategoria;
            Categoria.find({nombreCategoria: categoriaModel.nombreCategoria}).exec((err, CategoriaEncontrada) => {
                if (err) return res.status(500).send({mensaje: "Error en la peticion de Categoria"});
                if (CategoriaEncontrada && CategoriaEncontrada.length >= 1) {
                    return res.status(500).send({mensaje: "La categoria ya existe"});
                } else {
                    categoriaModel.save((err, CategoriaGuardada) => {
                        if (err) return res.status(500).send({ mensaje: "Error en la peticion de Guardar categoria" });
                        if (CategoriaGuardada) {
                            res.status(200).send({CategoriaGuardada})
                        } else {
                            res.status(404).send({mensaje: "No se ha podido registrar la categoria"})
                        }
                    })}
            })}else{
                return res.status(500).send({ mensaje: 'Un cliente no puede agregar una categoria' });
    }}
}

function deleteCategoria(req, res) {

    var IDCategoria = req.params.id;
    var params = req.body; 
    if(req.user.rol != "ROL_ADMIN"){
        return res.status(500).send({mensaje: "Error al eliminar categoria"});
    }
    if(IDCategoria === "604c322b804eaa4698ecb604"){
        return res.status(500).send({mensaje: "Error al eliminar categoria"});
    }
    Categoria.findByIdAndDelete(IDCategoria,(err, cateEliminada)=>{
        if(err) return res.status(500).send({mensaje:"Error en peticion"});
            if(!cateEliminada) return res.status(500).send({mensaje:"Error al eliminar categoria"});
            return res.status(200).send({mensaje: "Categoria eliminada"});
    })
    Producto.updateMany({IDCategoria: IDCategoria}, params, {new: true}, (err, productoActualizado) =>{
        if (err) return res.status(500).send({mensaje: "Error en peticion"});
            if (!productoActualizado) return res.status(500).send({mensaje: "Error en peticion"});
    })
}

function updateCate(req, res) {

    var IDCategoria = req.params.id;
    var params = req.body; 
    Categoria.find({nombreCategoria: params.nombreCategoria}).exec((err, CategoriaEncontrada) =>{
        if (err) return res.status(500).send({mensaje: "Error en peticion"});
            if (CategoriaEncontrada && CategoriaEncontrada.length >= 1) {
                return res.status(500).send({mensaje: "Categoria existente"});
    }
    if (req.user.rol === "ROL_ADMIN") {
        Categoria.findByIdAndUpdate(IDCategoria, params, {new: true}, (err, CategoriaActualizada) =>{
        if (err) return res.status(500).send({ mensaje: "Error en peticion" });
        if (!CategoriaActualizada) return res.status(500).send({ mensaje: "Error al editar" });
        return res.status(200).send({CategoriaActualizada})
        })
    }else{
        return res.status(404).send({mensaje: "No puedes editar"});
    }
})
}


function getCate(req, res) {

    Categoria.find().exec((err, categorias) => {
        if (err) return res.status(500).send({mensaje: "Error en peticion"});
        if (!categorias) return res.status(500).send({mensaje: "Error en peticion"});
        return res.status(200).send({categorias});
        })
}


module.exports = {
    pruebaControlador,
    prede,
    createCategoria,
    updateCate,
    deleteCategoria,
    getCate
}