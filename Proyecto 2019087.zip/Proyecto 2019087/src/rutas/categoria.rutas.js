"use strict"
var express = require("express");
var categoriaControlador = require("../controladores/categoria.controlador");
var md_autorizacion = require("../middlewares/authenticated");

var api = express.Router();

api.post("/createCategoria", md_autorizacion.ensureAuth, categoriaControlador.createCategoria);
api.delete("/deleteCategoria/:id", md_autorizacion.ensureAuth, categoriaControlador.deleteCategoria);
api.put("/updateCate/:id", md_autorizacion.ensureAuth, categoriaControlador.updateCate);
api.get("/getCate", categoriaControlador.getCate);


module.exports = api;