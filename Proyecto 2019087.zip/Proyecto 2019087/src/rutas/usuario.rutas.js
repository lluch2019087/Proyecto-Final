"use strict"

var express = require("express");
var usuarioControlador = require("../controladores/usuario.controlador");
var md_autorizacion = require("../middlewares/authenticated");

var api = express.Router();
api.post("/createCliente", usuarioControlador.createCliente);
api.post("/login", usuarioControlador.login);
api.put("/update", md_autorizacion.ensureAuth, usuarioControlador.update);
api.delete("/deleteUser/:id", md_autorizacion.ensureAuth, usuarioControlador.deleteUser);

module.exports = api;