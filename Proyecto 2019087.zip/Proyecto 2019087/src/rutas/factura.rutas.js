"use strict"
var express = require("express");
var facturaControlador = require("../controladores/factura.controlador");
var md_autorizacion = require("../middlewares/authenticated");

var api = express.Router();

api.post("/CreateFactura", facturaControlador.CreateFactura);
api.delete("/facturaCancel", facturaControlador.facturaCancel);
api.put("/facturaFinal", facturaControlador.facturaFinal);
module.exports = api;