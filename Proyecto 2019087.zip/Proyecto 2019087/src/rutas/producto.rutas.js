"use strict"
var express = require("express");
var productoControlador = require("../controladores/producto.controlador");
var md_autorizacion = require("../middlewares/authenticated");

var api = express.Router();

api.post("/createProd", md_autorizacion.ensureAuth, productoControlador.createProd);
api.put("/updateProd/:id", md_autorizacion.ensureAuth, productoControlador.updateProd);
api.delete("/deleteProd/:id", md_autorizacion.ensureAuth, productoControlador.deleteProd);
api.get("/getProd", productoControlador.getProd);
api.get("/getProductoCategoria/:id", productoControlador.getProductoCategoria);
api.get("/getAgotados", productoControlador.getAgotados);
api.get("/getNombre", productoControlador.getNombre);


module.exports = api;