"use strict"

var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var ProductoSchema = Schema({
    nombre: String,
    cantidad: Number,
    importe: Number,
    IDCategoria: {type: Schema.Types.ObjectId, ref: "categorias"}
});

module.exports = mongoose.model("productos", ProductoSchema);